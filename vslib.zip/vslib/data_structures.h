#ifndef DATA_STRUCTURES_H
#define DATA_STRUCTURES_H

#include "singly_linked_list.h"

#endif
